#ifndef __AUX03_H__
#define __AUX03_H__

#include <math.h>

// unknown function
//
double function_to_be_integrated(double x);

#endif
